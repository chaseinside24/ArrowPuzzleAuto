# Arrow Puzzle Auto (Android)

Exponential Idle의 **Arrow Puzzle Hard** 전용 자동 풀이 앱 소스 프로젝트입니다. 사용자가 제공한 Galaxy S23 스크린샷의 화면 비율과 37개 타일 좌표를 기준으로 작성했습니다.

## 구현 범위

- Android `MediaProjection`으로 화면을 직접 캡처합니다.
- 각 타일의 원 내부 색을 표본화해 검정색 `1` / 회색 `2`를 판독합니다.
- 37개 타일의 육각 격자를 구성하고, GF(2) 가우스-조르당 소거법으로 최소 클릭 해법을 구합니다.
- `AccessibilityService`의 제스처 API로 계산된 타일을 터치합니다.
- 모든 타일이 `1`이고 하단의 완료 문구가 확인된 경우에만 보상 버튼을 누릅니다.
- 새 퍼즐을 인식해 반복합니다.
- 알림에서 일시정지/재개 및 중지를 할 수 있습니다.

## 중요한 현재 상태

이 환경에는 Android SDK/Gradle 빌드 도구가 설치되어 있지 않아 **APK를 빌드하거나 실제 Galaxy S23에서 터치 테스트하지 못했습니다.** 따라서 이 파일은 완성 APK가 아니라 Android Studio에서 빌드할 수 있도록 구성한 소스 프로젝트입니다.

제공된 첫 번째 미해결 스크린샷의 37개 타일 상태를 수동 교차 확인해 해법을 계산했으며, 현재 모델에서는 12회 클릭 해법이 나옵니다. 순수 Java 코어 테스트에서는 무작위로 생성한 도달 가능한 보드 500개를 모두 풀고 결과를 검증했습니다. 그래도 화면 좌표/실제 게임 입력은 기기에서 테스트해야 하므로, 인식이 불확실하거나 방정식에 해가 없으면 앱이 클릭을 강행하지 않도록 했습니다.

## 빌드

1. Android Studio에서 이 폴더 `ArrowPuzzleAuto`를 엽니다.
2. Android SDK Platform 35와 JDK 17 이상을 설치합니다.
3. Gradle Sync가 끝나면 `app`의 `assembleDebug` 작업을 실행합니다.
4. 생성되는 APK는 `app/build/outputs/apk/debug/app-debug.apk`입니다.

## 휴대폰 설정 및 실행

1. Exponential Idle에서 Arrow Puzzle의 **Hard** 퍼즐을 열어 둡니다.
2. 앱을 설치하고 실행합니다.
3. `1. 접근성 터치 권한 설정`에서 **Arrow Puzzle Auto 터치 서비스**를 켭니다.
4. 앱으로 돌아와 `2. 화면 캡처 허용 및 자동 시작`을 누르고 Android의 전체 화면 공유 허용을 승인합니다.
5. 자동화가 시작되면 앱 작업이 뒤로 이동하며, 열려 있던 게임 화면을 대상으로 동작합니다.
6. 상태/제어는 알림의 일시정지·재개·중지 버튼으로 조작합니다. 화면은 켜 둔 상태로 유지하고, 세로 방향과 기본 화면 배율을 사용하세요.

## 지원 화면

- 기준 기기: Galaxy S23 계열의 1080×2340 세로 화면 비율
- 게임 모드: Arrow Puzzle Hard
- 타일 표시: 숫자 모드, 검정 `1`, 회색 `2`
- 퍼즐 보드가 스크린샷과 같은 위치/크기로 표시되는 화면

기기 글꼴 크기나 화면 확대, 게임 UI 배율, 분할 화면/팝업 화면, 회전 상태가 바뀌면 타일 중심좌표의 재보정이 필요할 수 있습니다.

## 안전장치

- 화면 비율이 맞지 않거나 37개 타일 모두를 판독하지 못하면 클릭하지 않습니다.
- 방정식이 모순되면 클릭하지 않고 일시정지합니다.
- 타일이 모두 `1`인 것만으로 하단 버튼을 누르지 않습니다. 완료 문구의 밝은 픽셀 폭도 별도로 확인합니다.
- 사용자가 알림에서 언제든 중지할 수 있습니다.


## PC 없이 갤럭시에서 빌드하기

1. Android 휴대폰에 MobileStudio를 설치합니다. 공식 프로젝트: https://github.com/MobileStudio-AndroidIDE/MobileStudio_AndroidIDE
2. MobileStudio에서 이 ZIP을 압축 해제한 `ArrowPuzzleAuto` 폴더를 엽니다.
3. 프로젝트 Gradle 버전은 8.7, JDK는 17을 선택합니다.
4. SDK Manager에서 Android SDK Platform 35를 설치합니다.
5. Build를 눌러 APK를 생성합니다.

이 프로젝트의 Android Gradle Plugin은 8.6.1이며 Gradle 8.7과 호환되도록 조정했습니다. MobileStudio 버전 및 기기 환경에 따라 빌드 UI가 다를 수 있습니다.
