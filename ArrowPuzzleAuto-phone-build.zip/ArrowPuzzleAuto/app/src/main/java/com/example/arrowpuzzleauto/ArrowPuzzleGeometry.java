package com.example.arrowpuzzleauto;

import java.util.ArrayList;
import java.util.List;

/** Screen profile measured from the supplied Galaxy S23 screenshot (709x1536 aspect ratio). */
public final class ArrowPuzzleGeometry {
    private ArrowPuzzleGeometry() {}

    public static final class PointN {
        public final float x;
        public final float y;
        public PointN(float x, float y) { this.x = x; this.y = y; }
    }

    // The visual board has seven vertical columns with 4,5,6,7,6,5,4 cells.
    private static final float[] X = {
            93f / 709f, 180f / 709f, 267f / 709f, 354f / 709f,
            442f / 709f, 529f / 709f, 616f / 709f
    };
    private static final int[][] Y = {
            {723, 824, 925, 1025},
            {673, 773, 874, 975, 1075},
            {622, 723, 824, 925, 1025, 1125},
            {572, 673, 773, 874, 975, 1075, 1176},
            {622, 723, 824, 925, 1025, 1125},
            {673, 773, 874, 975, 1075},
            {723, 824, 925, 1025}
    };

    public static List<PointN> centers() {
        List<PointN> result = new ArrayList<>(37);
        for (int c = 0; c < X.length; c++) {
            for (int y : Y[c]) result.add(new PointN(X[c], y / 1536f));
        }
        return result;
    }

    public static float sampleRadiusN() {
        return 24f / 709f;
    }

    public static PointN claimButtonCenter() {
        // Center of the bottom completion/claim button in the provided screenshots.
        return new PointN(313f / 709f, 1352f / 1536f);
    }
}
