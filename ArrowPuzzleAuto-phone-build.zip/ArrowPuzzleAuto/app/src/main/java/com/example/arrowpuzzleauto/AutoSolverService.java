package com.example.arrowpuzzleauto;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.content.pm.ServiceInfo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AutoSolverService extends Service {
    public static final String ACTION_START = "com.example.arrowpuzzleauto.START";
    public static final String ACTION_STOP = "com.example.arrowpuzzleauto.STOP";
    public static final String ACTION_TOGGLE_PAUSE = "com.example.arrowpuzzleauto.TOGGLE_PAUSE";
    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";

    private static final String CHANNEL_ID = "arrow_puzzle_auto";
    private static final int NOTIFICATION_ID = 9021;

    private volatile boolean running;
    private volatile boolean paused;
    private volatile String status = "준비 중";
    private volatile int solvedCount;
    private ExecutorService worker;
    private MediaProjection projection;
    private ScreenCaptureEngine captureEngine;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopAutomation();
            return START_NOT_STICKY;
        }
        if (ACTION_TOGGLE_PAUSE.equals(action)) {
            paused = !paused;
            setStatus(paused ? "일시정지" : "재개됨");
            return START_STICKY;
        }
        if (ACTION_START.equals(action) && !running) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData;
            if (Build.VERSION.SDK_INT >= 33) {
                resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
            } else {
                //noinspection deprecation
                resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            }
            if (resultData == null) {
                stopSelf();
                return START_NOT_STICKY;
            }
            startForegroundCompat();
            startCapture(resultCode, resultData);
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        Notification notification = buildNotification("게임의 퍼즐 화면을 기다리는 중");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void startCapture(int resultCode, Intent data) {
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("화면 캡처 권한을 받지 못했습니다.");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    running = false;
                    stopSelf();
                }
            }, mainHandler);
            captureEngine = new ScreenCaptureEngine(this, projection);
            captureEngine.start();
            running = true;
            paused = false;
            worker = Executors.newSingleThreadExecutor();
            worker.execute(this::automationLoop);
            setStatus("화면 인식 대기 중");
        } catch (Throwable t) {
            setStatus("시작 실패: " + safeMessage(t));
            stopAutomation();
        }
    }

    private void automationLoop() {
        BoardRecognizer recognizer = new BoardRecognizer();
        HardPuzzleSolver solver = new HardPuzzleSolver();
        long lastTimestamp = 0L;
        int consecutiveUnsolvable = 0;
        int consecutiveBadFrames = 0;
        try {
            while (running) {
                if (paused) {
                    SystemClock.sleep(250);
                    continue;
                }

                ScreenFrame frame = captureEngine.waitForFrameAfter(lastTimestamp, 3000);
                if (frame == null) {
                    setStatus("화면 프레임 대기 중");
                    continue;
                }
                lastTimestamp = Math.max(lastTimestamp, frame.timestampNs);
                BoardRecognizer.Result board = recognizer.read(frame);
                if (board == null || board.unknownTiles > 0) {
                    consecutiveBadFrames++;
                    setStatus("퍼즐 화면 인식 중 · 미확인 칸 " + (board == null ? "-" : board.unknownTiles));
                    SystemClock.sleep(350);
                    if (consecutiveBadFrames > 40) {
                        pauseWithStatus("Hard 퍼즐 화면을 찾지 못했습니다. 게임 화면을 확인하세요.");
                    }
                    continue;
                }
                consecutiveBadFrames = 0;

                if (board.isSolved()) {
                    if (board.claimTextVisible) {
                        ArrowPuzzleGeometry.PointN target = ArrowPuzzleGeometry.claimButtonCenter();
                        boolean tapped = TapAccessibilityService.tap(target.x * frame.width,
                                target.y * frame.height, 45, 1500);
                        if (!tapped) {
                            pauseWithStatus("보상 버튼 터치에 실패했습니다. 접근성 권한을 확인하세요.");
                            continue;
                        }
                        solvedCount++;
                        consecutiveUnsolvable = 0;
                        setStatus("클리어 " + solvedCount + "회 · 다음 퍼즐 대기");
                        SystemClock.sleep(1200);
                        continue;
                    } else {
                        setStatus("모든 타일이 1입니다. 완료 표시를 기다리는 중");
                        SystemClock.sleep(350);
                        continue;
                    }
                }

                int[] taps = solver.solve(board.states);
                if (taps == null) {
                    consecutiveUnsolvable++;
                    setStatus("현재 보드에서 해를 찾지 못했습니다 · 재인식 " + consecutiveUnsolvable + "/5");
                    SystemClock.sleep(400);
                    if (consecutiveUnsolvable >= 5) {
                        pauseWithStatus("보드 인식 또는 퍼즐 상태가 해법과 일치하지 않습니다. 오동작 방지를 위해 일시정지했습니다.");
                    }
                    continue;
                }
                consecutiveUnsolvable = 0;
                setStatus("해법 계산 완료 · " + taps.length + "칸 터치 중");
                boolean allTapped = true;
                for (int index : taps) {
                    if (!running || paused) { allTapped = false; break; }
                    ArrowPuzzleGeometry.PointN p = ArrowPuzzleGeometry.centers().get(index);
                    boolean ok = TapAccessibilityService.tap(p.x * frame.width, p.y * frame.height, 22, 1500);
                    if (!ok) { allTapped = false; break; }
                    SystemClock.sleep(35);
                }
                if (!allTapped) {
                    if (running && !paused) pauseWithStatus("타일 터치가 중단되었습니다. 접근성 서비스를 확인하세요.");
                    continue;
                }
                setStatus("터치 완료 · 결과 확인 중");
                SystemClock.sleep(550);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Throwable t) {
            pauseWithStatus("자동화 오류: " + safeMessage(t));
        }
    }

    private void pauseWithStatus(String message) {
        paused = true;
        setStatus(message);
    }

    private void setStatus(String value) {
        status = value;
        mainHandler.post(() -> {
            if (running) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(NOTIFICATION_ID, buildNotification(status));
            }
        });
    }

    private Notification buildNotification(String text) {
        Intent toggle = new Intent(this, AutoSolverService.class).setAction(ACTION_TOGGLE_PAUSE);
        Intent stop = new Intent(this, AutoSolverService.class).setAction(ACTION_STOP);
        PendingIntent togglePi = PendingIntent.getService(this, 1, toggle,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("Arrow Puzzle Auto")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(0, paused ? "재개" : "일시정지", togglePi).build())
                .addAction(new Notification.Action.Builder(0, "중지", stopPi).build());
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Arrow Puzzle Auto", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Arrow Puzzle 자동 풀이 상태 및 제어");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    private String safeMessage(Throwable t) {
        String message = t.getMessage();
        return message == null ? t.getClass().getSimpleName() : message;
    }

    private void stopAutomation() {
        running = false;
        paused = false;
        if (worker != null) { worker.shutdownNow(); worker = null; }
        if (captureEngine != null) { captureEngine.close(); captureEngine = null; }
        if (projection != null) {
            try { projection.stop(); } catch (Throwable ignored) { }
            projection = null;
        }
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.shutdownNow();
        if (captureEngine != null) captureEngine.close();
        if (projection != null) {
            try { projection.stop(); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
