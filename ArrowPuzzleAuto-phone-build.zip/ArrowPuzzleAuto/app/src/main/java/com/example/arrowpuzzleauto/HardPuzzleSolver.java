package com.example.arrowpuzzleauto;

import java.util.ArrayList;
import java.util.List;

/**
 * Exact solver for the 37-cell Hard board over GF(2).
 * Input states: 1 = up, 2 = down. A tap flips the selected cell and its six hex neighbours.
 */
public final class HardPuzzleSolver {
    public static final int SIZE = 37;
    private static final int RHS_BIT = SIZE;
    private static final long COEFFICIENT_MASK = (1L << SIZE) - 1L;

    private final int[][] triples = buildTriples();
    private final long[] matrixRows = buildMatrixRows();

    /** Returns tap indices (0..36), minimizing the number of taps; null means no exact solution. */
    public int[] solve(int[] states) {
        if (states == null || states.length != SIZE) throw new IllegalArgumentException("Expected 37 tile states");
        long[] rows = new long[SIZE];
        for (int r = 0; r < SIZE; r++) {
            int state = states[r];
            if (state != 1 && state != 2) throw new IllegalArgumentException("Tile states must be 1 or 2");
            rows[r] = matrixRows[r] | ((long) (state == 2 ? 1 : 0) << RHS_BIT);
        }

        int rank = 0;
        int[] pivotColumn = new int[SIZE];
        boolean[] isPivot = new boolean[SIZE];
        for (int col = 0; col < SIZE; col++) {
            int pivot = -1;
            for (int r = rank; r < SIZE; r++) {
                if (((rows[r] >>> col) & 1L) != 0L) { pivot = r; break; }
            }
            if (pivot < 0) continue;
            long tmp = rows[rank]; rows[rank] = rows[pivot]; rows[pivot] = tmp;
            for (int r = 0; r < SIZE; r++) {
                if (r != rank && ((rows[r] >>> col) & 1L) != 0L) rows[r] ^= rows[rank];
            }
            pivotColumn[rank] = col;
            isPivot[col] = true;
            rank++;
        }

        for (int r = rank; r < SIZE; r++) {
            if ((rows[r] & COEFFICIENT_MASK) == 0L && ((rows[r] >>> RHS_BIT) & 1L) != 0L) return null;
        }

        int[] freeColumns = new int[SIZE - rank];
        int freeCount = 0;
        for (int c = 0; c < SIZE; c++) if (!isPivot[c]) freeColumns[freeCount++] = c;

        // The Hard board matrix has rank 33 (four free variables): test all 16 solutions
        // and choose the one with the fewest taps.
        int[] best = null;
        int bestWeight = Integer.MAX_VALUE;
        int combinations = 1 << freeCount;
        for (int assignment = 0; assignment < combinations; assignment++) {
            int[] x = new int[SIZE];
            for (int j = 0; j < freeCount; j++) x[freeColumns[j]] = (assignment >>> j) & 1;
            for (int r = 0; r < rank; r++) {
                int col = pivotColumn[r];
                long row = rows[r];
                int value = (int) ((row >>> RHS_BIT) & 1L);
                for (int j = 0; j < freeCount; j++) {
                    if (((row >>> freeColumns[j]) & 1L) != 0L) value ^= x[freeColumns[j]];
                }
                x[col] = value;
            }
            int weight = 0;
            for (int v : x) weight += v;
            if (weight < bestWeight) { bestWeight = weight; best = x; }
        }

        // Verify the selected solution before returning it.
        if (best == null) return null;
        for (int r = 0; r < SIZE; r++) {
            int parity = 0;
            long row = matrixRows[r];
            for (int c = 0; c < SIZE; c++) if (((row >>> c) & 1L) != 0L) parity ^= best[c];
            if (parity != (states[r] == 2 ? 1 : 0)) return null;
        }

        int[] taps = new int[bestWeight];
        int k = 0;
        for (int i = 0; i < SIZE; i++) if (best[i] == 1) taps[k++] = i;
        return taps;
    }

    private int[][] buildTriples() {
        List<int[]> list = new ArrayList<>(SIZE);
        // i is the horizontal column coordinate. For each i, j runs top-to-bottom.
        for (int i = -3; i <= 3; i++) {
            for (int j = -3; j <= 3; j++) {
                int k = -i - j;
                if (k >= -3 && k <= 3) list.add(new int[]{i, j, k});
            }
        }
        if (list.size() != SIZE) throw new IllegalStateException("Bad hex-grid geometry");
        return list.toArray(new int[0][]);
    }

    private long[] buildMatrixRows() {
        long[] rows = new long[SIZE];
        for (int r = 0; r < SIZE; r++) {
            int[] a = triples[r];
            for (int c = 0; c < SIZE; c++) {
                int[] b = triples[c];
                int distance = Math.max(Math.abs(a[0] - b[0]),
                        Math.max(Math.abs(a[1] - b[1]), Math.abs(a[2] - b[2])));
                if (distance <= 1) rows[r] |= (1L << c); // includes the tile itself
            }
        }
        return rows;
    }
}
