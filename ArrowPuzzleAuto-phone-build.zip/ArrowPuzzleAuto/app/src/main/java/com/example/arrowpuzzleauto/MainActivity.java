package com.example.arrowpuzzleauto;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4101;
    private static final int REQUEST_NOTIFICATIONS = 4102;
    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void buildUi() {
        int pad = dp(20);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, pad, pad, pad);
        content.setBackgroundColor(0xFFF4F6FA);

        TextView title = new TextView(this);
        title.setText("Arrow Puzzle Auto");
        title.setTextSize(26);
        title.setTextColor(0xFF172033);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(0, dp(12), 0, dp(8));
        content.addView(title, matchWrap());

        TextView intro = new TextView(this);
        intro.setText("Exponential Idle의 Arrow Puzzle Hard(37칸)를 화면에서 읽고, GF(2) 해법을 계산해 자동으로 누릅니다. 클리어를 확인한 뒤 보상 버튼을 누르고 다음 퍼즐을 반복합니다.");
        intro.setTextSize(16);
        intro.setTextColor(0xFF39445B);
        intro.setLineSpacing(dp(4), 1.0f);
        content.addView(intro, matchWrap());

        Button accessibility = new Button(this);
        accessibility.setText("1. 접근성 터치 권한 설정");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addSpaced(content, accessibility);

        Button start = new Button(this);
        start.setText("2. 화면 캡처 허용 및 자동 시작");
        start.setOnClickListener(v -> beginCaptureAndStart());
        addSpaced(content, start);

        Button stop = new Button(this);
        stop.setText("자동화 중지");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, AutoSolverService.class);
            i.setAction(AutoSolverService.ACTION_STOP);
            startService(i);
            Toast.makeText(this, "중지 요청을 보냈습니다.", Toast.LENGTH_SHORT).show();
        });
        addSpaced(content, stop);

        statusView = new TextView(this);
        statusView.setTextSize(14);
        statusView.setTextColor(0xFF26334A);
        statusView.setPadding(0, dp(18), 0, 0);
        content.addView(statusView, matchWrap());

        TextView instructions = new TextView(this);
        instructions.setText("사용 순서\n① 게임에서 Arrow Puzzle → Hard를 열어 둡니다.\n② 이 앱으로 돌아와 접근성 권한을 켭니다.\n③ 자동 시작을 누르고 전체 화면 공유를 허용합니다.\n④ 게임 화면으로 돌아가면 자동 풀이가 시작됩니다.\n\n화면 인식이 불확실하거나 수학적 해가 없으면 잘못 누르지 않고 멈춥니다. 알림에서 일시정지·재개·중지를 제어할 수 있습니다.");
        instructions.setTextSize(14);
        instructions.setTextColor(0xFF59657B);
        instructions.setLineSpacing(dp(4), 1.0f);
        instructions.setPadding(0, dp(20), 0, 0);
        content.addView(instructions, matchWrap());

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        setContentView(scroll);
        refreshStatus();
    }

    private void beginCaptureAndStart() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "먼저 접근성 터치 권한을 켜 주세요.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, AutoSolverService.class);
                service.setAction(AutoSolverService.ACTION_START);
                service.putExtra(AutoSolverService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(AutoSolverService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                else startService(service);
                Toast.makeText(this, "자동화 서비스를 시작했습니다.", Toast.LENGTH_SHORT).show();
                // The game should already be open underneath this activity.
                new android.os.Handler(getMainLooper()).postDelayed(() -> moveTaskToBack(true), 350);
            } else {
                Toast.makeText(this, "화면 캡처 권한이 취소되었습니다.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = getPackageName() + "/" + TapAccessibilityService.class.getName();
        for (String component : enabled.split(":")) {
            if (component.equalsIgnoreCase(target)) return true;
        }
        return false;
    }

    private void refreshStatus() {
        if (statusView == null) return;
        String accessibility = isAccessibilityEnabled() ? "켜짐" : "꺼짐";
        statusView.setText("접근성 터치 서비스: " + accessibility + "\n앱 버전: 1.0.0 · 대상: Hard / 37 tiles / 숫자 1·2");
    }

    private void addSpaced(LinearLayout parent, View view) {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(12);
        parent.addView(view, lp);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
