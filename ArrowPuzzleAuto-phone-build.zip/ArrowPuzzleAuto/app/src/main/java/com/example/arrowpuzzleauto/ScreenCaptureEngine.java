package com.example.arrowpuzzleauto;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.nio.ByteBuffer;

public final class ScreenCaptureEngine implements AutoCloseable {
    private final Context context;
    private final MediaProjection projection;
    private HandlerThread thread;
    private Handler handler;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private final Object lock = new Object();
    private ScreenFrame latestFrame;
    private boolean closed;

    public ScreenCaptureEngine(Context context, MediaProjection projection) {
        this.context = context.getApplicationContext();
        this.projection = projection;
    }

    public void start() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        display.getRealMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        if (width <= 0 || height <= 0) throw new IllegalStateException("Invalid display size");

        thread = new HandlerThread("ArrowPuzzleScreenCapture");
        thread.start();
        handler = new Handler(thread.getLooper());
        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 3);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null) return;
                Image.Plane plane = image.getPlanes()[0];
                ByteBuffer buffer = plane.getBuffer();
                byte[] data = new byte[buffer.remaining()];
                buffer.get(data);
                ScreenFrame frame = new ScreenFrame(image.getWidth(), image.getHeight(),
                        plane.getRowStride(), plane.getPixelStride(), data, image.getTimestamp());
                synchronized (lock) {
                    latestFrame = frame;
                    lock.notifyAll();
                }
            } catch (Throwable ignored) {
            } finally {
                if (image != null) image.close();
            }
        }, handler);
        virtualDisplay = projection.createVirtualDisplay("ArrowPuzzleAutoCapture", width, height,
                metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, handler);
        if (virtualDisplay == null) throw new IllegalStateException("Could not create screen capture display");
    }

    public ScreenFrame waitForFrameAfter(long timestampNs, long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        synchronized (lock) {
            while (!closed) {
                if (latestFrame != null && latestFrame.timestampNs > timestampNs) return latestFrame;
                long remaining = deadline - System.currentTimeMillis();
                if (remaining <= 0) return null;
                lock.wait(Math.min(remaining, 250));
            }
            return null;
        }
    }

    public ScreenFrame latest() {
        synchronized (lock) { return latestFrame; }
    }

    @Override
    public void close() {
        synchronized (lock) { closed = true; lock.notifyAll(); }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        if (thread != null) { thread.quitSafely(); thread = null; }
    }
}
