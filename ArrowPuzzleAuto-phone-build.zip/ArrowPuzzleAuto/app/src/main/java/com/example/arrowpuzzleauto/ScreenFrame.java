package com.example.arrowpuzzleauto;

public final class ScreenFrame {
    public final int width;
    public final int height;
    public final int rowStride;
    public final int pixelStride;
    public final byte[] rgba;
    public final long timestampNs;

    public ScreenFrame(int width, int height, int rowStride, int pixelStride, byte[] rgba, long timestampNs) {
        this.width = width;
        this.height = height;
        this.rowStride = rowStride;
        this.pixelStride = pixelStride;
        this.rgba = rgba;
        this.timestampNs = timestampNs;
    }

    public int luminance(int x, int y) {
        x = Math.max(0, Math.min(width - 1, x));
        y = Math.max(0, Math.min(height - 1, y));
        int offset = y * rowStride + x * pixelStride;
        if (offset < 0 || offset + 2 >= rgba.length) return 0;
        int r = rgba[offset] & 0xFF;
        int g = rgba[offset + 1] & 0xFF;
        int b = rgba[offset + 2] & 0xFF;
        return (299 * r + 587 * g + 114 * b) / 1000;
    }
}
