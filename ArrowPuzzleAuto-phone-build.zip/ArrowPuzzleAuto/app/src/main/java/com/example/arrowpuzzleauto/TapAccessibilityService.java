package com.example.arrowpuzzleauto;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class TapAccessibilityService extends AccessibilityService {
    private static volatile TapAccessibilityService instance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean isConnected() {
        return instance != null;
    }

    /** Dispatch one screen-coordinate tap and wait for Android's gesture callback. */
    public static boolean tap(float x, float y, long durationMs, long timeoutMs) {
        TapAccessibilityService service = instance;
        if (service == null) return false;
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean completed = new AtomicBoolean(false);
        service.mainHandler.post(() -> {
            try {
                Path path = new Path();
                path.moveTo(x, y);
                GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(
                        path, 0, Math.max(1L, durationMs));
                GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
                boolean accepted = service.dispatchGesture(gesture, new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gestureDescription) {
                        completed.set(true);
                        latch.countDown();
                    }
                    @Override public void onCancelled(GestureDescription gestureDescription) {
                        completed.set(false);
                        latch.countDown();
                    }
                }, null);
                if (!accepted) latch.countDown();
            } catch (Throwable t) {
                latch.countDown();
            }
        });
        try {
            latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return completed.get();
    }
}
