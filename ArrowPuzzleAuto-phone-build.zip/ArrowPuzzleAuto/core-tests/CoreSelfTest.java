import com.example.arrowpuzzleauto.HardPuzzleSolver;
import java.util.Random;

public final class CoreSelfTest {
    public static void main(String[] args) {
        HardPuzzleSolver solver = new HardPuzzleSolver();
        Random random = new Random(7);
        for (int trial = 0; trial < 500; trial++) {
            int[] state = new int[37];
            java.util.Arrays.fill(state, 1);
            // Generate a guaranteed-reachable board by applying random legal taps.
            int[] parity = new int[37];
            for (int i = 0; i < 37; i++) if (random.nextBoolean()) parity[i] ^= 1;
            for (int tap = 0; tap < 37; tap++) {
                if (parity[tap] == 0) continue;
                // Use the same triple-coordinate adjacency definition as the solver.
                int[] a = triple(tap);
                for (int cell = 0; cell < 37; cell++) {
                    int[] b = triple(cell);
                    if (Math.max(Math.abs(a[0]-b[0]), Math.max(Math.abs(a[1]-b[1]), Math.abs(a[2]-b[2]))) <= 1)
                        state[cell] = state[cell] == 1 ? 2 : 1;
                }
            }
            int[] solution = solver.solve(state);
            if (solution == null) throw new AssertionError("Reachable board was not solved at trial " + trial);
            for (int tap : solution) {
                int[] a = triple(tap);
                for (int cell = 0; cell < 37; cell++) {
                    int[] b = triple(cell);
                    if (Math.max(Math.abs(a[0]-b[0]), Math.max(Math.abs(a[1]-b[1]), Math.abs(a[2]-b[2]))) <= 1)
                        state[cell] = state[cell] == 1 ? 2 : 1;
                }
            }
            for (int value : state) if (value != 1) throw new AssertionError("Solver output failed verification");
        }
        System.out.println("PASS: 500 reachable Hard-board states solved and verified.");
    }

    private static int[] triple(int index) {
        int cursor = 0;
        for (int i = -3; i <= 3; i++) {
            for (int j = -3; j <= 3; j++) {
                int k = -i-j;
                if (k < -3 || k > 3) continue;
                if (cursor++ == index) return new int[]{i,j,k};
            }
        }
        throw new IllegalArgumentException();
    }
}
