import com.example.arrowpuzzleauto.HardPuzzleSolver;

public final class ScreenshotStateCheck {
    public static void main(String[] args) {
        // States from the user's first screenshot, in screen-geometry order.
        int[][] columns = {
            {1,2,1,2},
            {1,1,2,2,2},
            {1,1,2,1,2,2},
            {1,1,1,2,2,1,2},
            {1,1,1,1,2,1},
            {2,2,2,1,2},
            {1,2,1,2}
        };
        int[] states = new int[37];
        int p = 0;
        for (int[] col : columns) for (int value : col) states[p++] = value;
        int[] answer = new HardPuzzleSolver().solve(states);
        if (answer == null) throw new AssertionError("Screenshot board had no solution");
        System.out.println("Screenshot board: exact solution with " + answer.length + " taps.");
        System.out.print("Indices (0-36):");
        for (int index : answer) System.out.print(" " + index);
        System.out.println();
    }
}
